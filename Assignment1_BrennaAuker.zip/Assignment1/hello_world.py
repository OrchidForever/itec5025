# Author: Brenna Auker
# Class: ITEC 5025
# This script prints "Hello, World" to the console.
try:
    print("Hello, World")
except Exception as e:
    print(f"An error occurred: {e}")